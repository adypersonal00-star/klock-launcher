package com.zapia.klocklauncher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.service.notification.StatusBarNotification
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

data class KApp(val name:String,val pkg:String,val icon:Drawable)
data class KNotice(val id:String,val title:String,val text:String,val pkg:String)
private val black=Color(0xFF05070A); private val surface=Color(0xFF111820); private val aqua=Color(0xFF70E8FF); private val lime=Color(0xFF82FFB6); private val amber=Color(0xFFFFD477)

class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{KlockApp()}}}
class KlockNotificationListener:android.service.notification.NotificationListenerService(){
 override fun onNotificationPosted(s:StatusBarNotification?){if(s!=null){val e=s.notification.extras;getSharedPreferences("klock",0).edit().putString("n_${s.key}",listOf(e.getCharSequence("android.title")?.toString().orEmpty(),e.getCharSequence("android.text")?.toString().orEmpty(),s.packageName).joinToString("¦")).apply()}}
 override fun onNotificationRemoved(s:StatusBarNotification?){if(s!=null)getSharedPreferences("klock",0).edit().remove("n_${s.key}").apply()}
}

@Composable private fun KlockApp(){
 val ctx= LocalContext.current; val prefs=remember{ctx.getSharedPreferences("klock",0)}
 var page by remember{mutableStateOf("watch")}; var now by remember{mutableStateOf(Date())}; var apps by remember{mutableStateOf(emptyList<KApp>())}; var query by remember{mutableStateOf("")}; var url by remember{mutableStateOf("")}; var loadedUrl by remember{mutableStateOf("")}; var widget by remember{mutableStateOf(prefs.getString("widget","clock")?:"clock")}; var alarms by remember{mutableStateOf(prefs.getStringSet("alarms", emptySet())!!.toList())}; var notices by remember{mutableStateOf(readNotices(prefs))}
 LaunchedEffect(Unit){while(true){now=Date();notices=readNotices(prefs);delay(1000)}}
 LaunchedEffect(Unit){val pm=ctx.packageManager;apps=pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),0).mapNotNull{r->runCatching{KApp(pm.getApplicationLabel(r.activityInfo.applicationInfo).toString(),r.activityInfo.packageName,pm.getApplicationIcon(r.activityInfo.applicationInfo))}.getOrNull()}.distinctBy{it.pkg}.filter{it.pkg!=ctx.packageName}.sortedBy{it.name.lowercase()}}
 MaterialTheme(colorScheme=darkColorScheme(primary=aqua,background=black,surface=surface,onSurface=Color.White)){
  Box(Modifier.fillMaxSize().background(black),contentAlignment=Alignment.Center){
   Column(Modifier.fillMaxHeight().fillMaxWidth(.96f).padding(vertical=5.dp),horizontalAlignment=Alignment.CenterHorizontally){
    Strap(Modifier.weight(.7f))
    Box(Modifier.fillMaxWidth().weight(5.6f).clip(RoundedCornerShape(42.dp)).background(Color(0xFF303741)).padding(8.dp),contentAlignment=Alignment.Center){
     Box(Modifier.fillMaxSize().clip(CircleShape).border(5.dp,Color(0xFF89939E),CircleShape).background(surface)
      .pointerInput(page){var d=0f;detectHorizontalDragGestures(onHorizontalDrag={_,x->d+=x},onDragEnd={if(d>55)page=when(page){"watch"->"widgets";"widgets"->"watch";else->"watch"};if(d< -55)page=when(page){"watch"->"apps";"apps"->"recent";else->"watch"};d=0f})}
      .pointerInput(page){var d=0f;detectVerticalDragGestures(onVerticalDrag={_,y->d+=y},onDragEnd={if(d< -55)page="apps";if(d>55)page="watch";d=0f})},contentAlignment=Alignment.Center){
       when(page){
        "watch"->WatchFace(now,apps,prefs.getString("favorites","")!!.split('|').filter{it.isNotBlank()},{a->open(ctx,a){page="apps"}})
        "apps"->AppsPage(apps,query,{query=it},prefs.getString("layout","grid")?:"grid",{open(ctx,it){page="apps"}},{page=it})
        "recent"->RecentPage(apps,prefs.getString("recent","")!!.split('|').filter{it.isNotBlank()},{open(ctx,it){page="apps"}})
        "widgets"->WidgetPage(widget,{widget=it;prefs.edit().putString("widget",it).apply()})
        "notices"->NoticesPage(notices,ctx)
        "settings"->SettingsPage(ctx,apps,prefs,{widget=it;prefs.edit().putString("widget",it).apply()})
        "clock"->ClockApp(now,alarms,{alarms=(alarms+it).distinct();prefs.edit().putStringSet("alarms",alarms.toSet()).apply()})
        "snake"->Snake()
        "catch"->Catch()
        "map"->MapGame()
        "browser"->Browser(url,{url=it},loadedUrl,{loadedUrl=if(it.startsWith("http"))it else "https://$it"})
        else->InternalMenu(now,alarms,{alarms=(alarms+it).distinct();prefs.edit().putStringSet("alarms",alarms.toSet()).apply()},{alarms=it;prefs.edit().putStringSet("alarms",it.toSet()).apply()},{page=it})
       }
      }
    }
    Row(Modifier.fillMaxWidth().height(54.dp),horizontalArrangement=Arrangement.End,verticalAlignment=Alignment.CenterVertically){Column(Modifier.width(36.dp).fillMaxHeight(),verticalArrangement=Arrangement.SpaceEvenly,horizontalAlignment=Alignment.CenterHorizontally){Side("‹"){page=if(page in listOf("apps","recent","widgets","notices","settings"))"watch" else "menu"};Side("⌂"){page="apps"};Side("▢"){page="recent"}}}
    Strap(Modifier.weight(.7f))
   }
  }
 }
}
@Composable private fun Strap(m:Modifier){Column(m.width(74.dp).clip(RoundedCornerShape(22.dp)).background(Color(0xFF20262D)),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){repeat(3){Box(Modifier.padding(2.dp).size(7.dp).background(Color(0xFF07090C),CircleShape))}}}
@Composable private fun Side(t:String,click:()->Unit){Box(Modifier.size(31.dp).clip(CircleShape).background(Color(0xFF8B949F)).clickable{click()},contentAlignment=Alignment.Center){Text(t,color=Color.Black,fontWeight=FontWeight.Bold,fontSize=17.sp)}}
@Composable private fun WatchFace(now:Date,apps:List<KApp>,fav:List<String>,onOpen:(KApp)->Unit){Column(Modifier.fillMaxSize().padding(27.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Text(SimpleDateFormat("EEE, MMM d",Locale.getDefault()).format(now),color=Color.LightGray,fontSize=12.sp);Text(SimpleDateFormat("HH:mm",Locale.getDefault()).format(now),color=Color.White,fontSize=47.sp,fontWeight=FontWeight.Light);Text(SimpleDateFormat("ss",Locale.getDefault()).format(now),color=aqua,fontSize=14.sp);Spacer(Modifier.height(18.dp));Row(horizontalArrangement=Arrangement.spacedBy(9.dp)){(if(fav.isEmpty())apps.take(4) else fav.mapNotNull{id->apps.firstOrNull{it.pkg==id}}).take(4).forEach{a->SmallApp(a){onOpen(a)}}};Spacer(Modifier.height(15.dp));Text("← widgets      apps →",color=Color.LightGray,fontSize=9.sp);Text("Swipe up for apps",color=Color.Gray,fontSize=8.sp)}}
@Composable private fun SmallApp(a:KApp,onClick:()->Unit){Column(Modifier.width(45.dp).clickable{onClick()},horizontalAlignment=Alignment.CenterHorizontally){IconImage(a.icon,Modifier.size(34.dp));Text(a.name,color=Color.White,fontSize=8.sp,maxLines=1,overflow=TextOverflow.Ellipsis)}}
@Composable private fun IconImage(d:Drawable,m:Modifier){val bitmap=remember(d){val w=d.intrinsicWidth.coerceAtLeast(1);val h=d.intrinsicHeight.coerceAtLeast(1);android.graphics.Bitmap.createBitmap(w,h,android.graphics.Bitmap.Config.ARGB_8888).also{b->d.setBounds(0,0,w,h);d.draw(android.graphics.Canvas(b))}};androidx.compose.foundation.Image(bitmap.asImageBitmap(),null,m)}
@Composable private fun AppsPage(apps:List<KApp>,q:String,onQuery:(String)->Unit,layout:String,onOpen:(KApp)->Unit,onInternal:(String)->Unit){var list by remember{mutableStateOf(layout=="list")};Column(Modifier.fillMaxSize().padding(25.dp),horizontalAlignment=Alignment.CenterHorizontally){Text("ALL APPS",color=aqua,fontSize=11.sp,fontWeight=FontWeight.Bold);TextButton(onClick={list=!list}){Text(if(list)"List · tap for pages" else "Pages · tap for list",color=Color.White,fontSize=9.sp)};Entry("Search",q,onQuery);val shown=apps.filter{it.name.contains(q,true)};if(list)LazyColumn{items(shown){a->Row(Modifier.fillMaxWidth().clickable{onOpen(a)}.padding(3.dp),verticalAlignment=Alignment.CenterVertically){IconImage(a.icon,Modifier.size(23.dp));Text(a.name,color=Color.White,fontSize=9.sp,modifier=Modifier.padding(start=5.dp))}}}else{Column(Modifier.weight(1f)){shown.take(18).chunked(3).forEach{r->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly){r.forEach{SmallApp(it){onOpen(it)}}}}}};Text("Built in",color=amber,fontSize=9.sp);Row{listOf("Clock","Snake","Map","Browser").forEach{label->Pill(label){onInternal(label.lowercase())}}};Row{listOf("Catch","Settings").forEach{label->Pill(label){onInternal(label.lowercase())}}}}}
@Composable private fun RecentPage(apps:List<KApp>,ids:List<String>,onOpen:(KApp)->Unit){Column(Modifier.fillMaxSize().padding(26.dp),horizontalAlignment=Alignment.CenterHorizontally){Text("RECENT APPS",color=aqua,fontSize=11.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(10.dp));ids.mapNotNull{id->apps.firstOrNull{it.pkg==id}}.take(8).forEach{SmallApp(it){onOpen(it)}}}}
@Composable private fun WidgetPage(selected:String,onSelect:(String)->Unit){Column(Modifier.fillMaxSize().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Text("WIDGETS",color=aqua,fontSize=12.sp,fontWeight=FontWeight.Bold);listOf("clock","calendar","steps","weather","notes").forEach{TextButton(onClick={onSelect(it)}){Text((if(it==selected)"● " else "○ ")+it,color=Color.White,fontSize=9.sp)}};Text("Swipe left from the watch face to open this page.",color=Color.Gray,fontSize=8.sp,textAlign=TextAlign.Center)}}
@Composable private fun NoticesPage(notices:List<KNotice>,ctx:Context){Column(Modifier.fillMaxSize().padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally){Text("NOTIFICATIONS",color=aqua,fontSize=11.sp,fontWeight=FontWeight.Bold);TextButton(onClick={ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}){Text("Enable notification access",color=aqua,fontSize=8.sp)};if(notices.isEmpty())Text("No notifications",color=Color.LightGray,fontSize=9.sp);LazyColumn{items(notices){n->Column(Modifier.fillMaxWidth().clickable{ctx.packageManager.getLaunchIntentForPackage(n.pkg)?.let{ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}}.padding(5.dp)){Text(n.title,color=Color.White,fontSize=9.sp,fontWeight=FontWeight.Bold);Text(n.text,color=Color.LightGray,fontSize=8.sp,maxLines=2)}}}}}
@Composable private fun SettingsPage(ctx:Context,apps:List<KApp>,p:android.content.SharedPreferences,onWidget:(String)->Unit){Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally){Text("KLOCK SETTINGS",color=aqua,fontSize=11.sp,fontWeight=FontWeight.Bold);Row{Pill("Grid"){p.edit().putString("layout","grid").apply()};Pill("List"){p.edit().putString("layout","list").apply()}};Text("Favorite face apps",color=Color.White,fontSize=9.sp);apps.take(15).forEach{a->var checked by remember{mutableStateOf(p.getString("favorites","")!!.split('|').contains(a.pkg))};Row(verticalAlignment=Alignment.CenterVertically){Checkbox(checked,{checked=it;val s=p.getString("favorites","")!!.split('|').filter{it.isNotBlank()}.toMutableSet();if(it)s.add(a.pkg)else s.remove(a.pkg);p.edit().putString("favorites",s.joinToString("|")).apply()},modifier=Modifier.size(25.dp));Text(a.name,color=Color.White,fontSize=8.sp)}};Pill("Notification access"){ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))};listOf("clock","calendar","steps","weather","notes").forEach{Pill("Widget: $it"){onWidget(it)}}}}
@Composable private fun InternalMenu(now:Date,alarms:List<String>,add:(String)->Unit,clear:(List<String>)->Unit,nav:(String)->Unit){Column(Modifier.fillMaxSize().padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Text("KLOCK APPS",color=aqua,fontSize=12.sp,fontWeight=FontWeight.Bold);listOf("clock" to "Clock","snake" to "Snake","map" to "Map","browser" to "Browser","catch" to "Catch","settings" to "Settings").forEach{(id,label)->Pill(label){nav(id)}}}}
@Composable private fun ClockApp(now:Date,alarms:List<String>,add:(String)->Unit){var hour by remember{mutableIntStateOf(7)};var minute by remember{mutableIntStateOf(0)};Column(horizontalAlignment=Alignment.CenterHorizontally){Text(SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(now),color=Color.White,fontSize=22.sp);Text("ALARMS",color=aqua,fontSize=10.sp);Row{Pill("−"){hour=(hour+23)%24};Text("%02d:%02d".format(hour,minute),color=amber,fontSize=18.sp);Pill("+"){minute=(minute+1)%60}};Pill("Set alarm"){add("%02d:%02d".format(hour,minute))};alarms.forEach{Text("⏰ $it",color=amber,fontSize=8.sp)}}}
@Composable private fun Snake(){var score by remember{mutableIntStateOf(0)};var dir by remember{mutableStateOf("→")};var snake by remember{mutableStateOf(listOf(3 to 4,2 to 4,1 to 4))};var food by remember{mutableStateOf(6 to 6)};LaunchedEffect(dir){while(true){delay(650);val h=snake.first();val n=when(dir){"↑"->h.first to (h.second-1+8)%8;"↓"->h.first to (h.second+1)%8;"←"->(h.first-1+8)%8 to h.second;else->(h.first+1)%8 to h.second};if(snake.contains(n)){score=0;snake=listOf(3 to 4,2 to 4,1 to 4)}else{snake=listOf(n)+if(n==food)snake else snake.dropLast(1);if(n==food){score++;food=Random.nextInt(8) to Random.nextInt(8)}}}};Column(horizontalAlignment=Alignment.CenterHorizontally){Text("SNAKE · $score",color=lime,fontSize=10.sp,fontWeight=FontWeight.Bold);(0..7).forEach{y->Row{(0..7).forEach{x->Box(Modifier.padding(1.dp).size(18.dp).background(if(x to y==food)amber else if(snake.contains(x to y))lime else Color(0xFF222A32),RoundedCornerShape(3.dp)))}}};Row{listOf("←","↑","↓","→").forEach{Pill(it){dir=it}}}}}
@Composable private fun Catch(){var score by remember{mutableIntStateOf(0)};var y by remember{mutableIntStateOf(5)};var x by remember{mutableIntStateOf(40)};LaunchedEffect(Unit){while(true){delay(450);y+=8;if(y>90){y=4;x=Random.nextInt(20,75)}}};Column(Modifier.fillMaxSize().padding(25.dp),horizontalAlignment=Alignment.CenterHorizontally){Text("CATCH · $score",color=amber,fontSize=10.sp);Box(Modifier.weight(1f).fillMaxWidth().clip(CircleShape).background(Color(0xFF171E25)).clickable{score++;y=5},contentAlignment=Alignment.Center){Text("✦",Modifier.align(Alignment.TopStart).padding(start=x.dp,top=y.dp),color=amber,fontSize=18.sp);Text("▰",Modifier.align(Alignment.BottomCenter),color=aqua,fontSize=22.sp)};Text("Tap to catch falling stars",color=Color.LightGray,fontSize=8.sp)}}
@Composable private fun MapGame(){var x by remember{mutableIntStateOf(3)};var y by remember{mutableIntStateOf(3)};Column(horizontalAlignment=Alignment.CenterHorizontally){Text("MAP",color=aqua,fontSize=11.sp,fontWeight=FontWeight.Bold);(0..7).forEach{r->Row{(0..7).forEach{c->Text(if(x==c&&y==r)"●" else if((c+r)%3==0)"·" else "▧",Modifier.clickable{x=c;y=r}.padding(3.dp),color=if(x==c&&y==r)aqua else Color.Gray,fontSize=10.sp)}}};Row{listOf("↑","←","↓","→").forEach{Pill(it){when(it){"↑"->y=(y+7)%8;"↓"->y=(y+1)%8;"←"->x=(x+7)%8;else->x=(x+1)%8}}}}}}
@Composable private fun Browser(url:String,onUrl:(String)->Unit,loaded:String,onLoad:(String)->Unit){Column(Modifier.fillMaxSize().padding(23.dp),horizontalAlignment=Alignment.CenterHorizontally){Text("KLOCK BROWSER",color=aqua,fontSize=10.sp);Entry("Address",url,onUrl);Pill("Go"){onLoad(if(url.startsWith("http"))url else "https://$url")};if(loaded.isNotBlank())AndroidView(factory={c->WebView(c).apply{settings.javaScriptEnabled=false;webViewClient=WebViewClient();loadUrl(loaded)}},update={it.loadUrl(loaded)},modifier=Modifier.weight(1f).fillMaxWidth())else Spacer(Modifier.weight(1f))}}
@Composable private fun Entry(label:String,value:String,onChange:(String)->Unit){Column(horizontalAlignment=Alignment.CenterHorizontally){Text(label,color=Color.Gray,fontSize=8.sp);Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(7.dp)).background(Color(0xFF26313B)).padding(5.dp)){BasicTextField(value,onChange,readOnly=true,singleLine=true,textStyle=TextStyle(color=Color.White,fontSize=9.sp),modifier=Modifier.fillMaxWidth())}};KKeyboard({onChange(value+it)},{onChange(value.dropLast(1))},{})}
@Composable private fun KKeyboard(type:(String)->Unit,back:()->Unit,enter:()->Unit){var sym by remember{mutableStateOf(false)};var emoji by remember{mutableStateOf(false)};var upper by remember{mutableStateOf(false)};val keys=if(sym)listOf("!@#$%^&*()","-_=+[]{};:","/?.<>,~`\\|")else listOf("1234567890","qwertyuiop","asdfghjkl","zxcvbnm");Column(Modifier.fillMaxWidth().padding(top=2.dp),horizontalAlignment=Alignment.CenterHorizontally){keys.forEach{r->Row(horizontalArrangement=Arrangement.Center){r.forEach{ch->val value=if(upper) ch.uppercaseChar().toString() else ch.toString();Key(value){type(value);upper=false}}}};Row{Key(if(upper)"⇧✓" else "⇧"){upper=!upper};Key("SPACE"){type(" ")};Key("⌫",back);Key("↵",enter)};Row{Key("SYM"){sym=!sym};Key("☺"){emoji=!emoji};Key("ABC"){sym=false}};if(emoji)Row{listOf("😀","😂","❤️","👍","🎉").forEach{Key(it){type(it)}}}}}
@Composable private fun Key(s:String,onClick:()->Unit){Box(Modifier.padding(1.dp).height(18.dp).defaultMinSize(minWidth=13.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF303C48)).clickable{onClick()}.padding(horizontal=3.dp),contentAlignment=Alignment.Center){Text(s,color=Color.White,fontSize=7.sp)}}
@Composable private fun Pill(s:String,onClick:()->Unit){Text(s,Modifier.padding(2.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF26323C)).clickable{onClick()}.padding(horizontal=5.dp,vertical=3.dp),color=aqua,fontSize=8.sp)}
private fun open(ctx:Context,a:KApp,done:()->Unit){if(a.pkg.startsWith("internal:")){done();return};val p=ctx.getSharedPreferences("klock",0);p.edit().putString("recent",(listOf(a.pkg)+p.getString("recent","")!!.split('|').filter{it.isNotBlank()&&it!=a.pkg}).take(8).joinToString("|")).apply();ctx.packageManager.getLaunchIntentForPackage(a.pkg)?.let{ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}}
private fun readNotices(p:android.content.SharedPreferences):List<KNotice> = p.all.entries.filter{it.key.startsWith("n_")}.mapNotNull{e->val d=(e.value as?String)?.split('¦')?:return@mapNotNull null;if(d.size<3)null else KNotice(e.key.removePrefix("n_"),d[0],d[1],d[2])}
